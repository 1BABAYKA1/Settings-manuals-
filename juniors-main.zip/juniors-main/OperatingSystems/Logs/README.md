## Логирование

### Rsyslog

Ссылки на документацию
(документация 1)[https://www.linuxtechi.com/setup-rsyslog-server-on-debian/]