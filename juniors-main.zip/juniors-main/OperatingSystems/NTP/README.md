# NTP

#### NTP Server OPNsense
[официальная документация](https://docs.opnsense.org/manual/ntpd.html)


#### NTP Client linux
[официальная документация](https://kifarunix.com/install-and-configure-ntp-client-on-ubuntu-debian-systems/)