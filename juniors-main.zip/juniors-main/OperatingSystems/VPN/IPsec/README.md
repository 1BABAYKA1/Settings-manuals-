## IPsec


#### IPsec OPNsense
[официальная документация](https://docs.opnsense.org/manual/how-tos/ipsec-s2s-conn.html)
